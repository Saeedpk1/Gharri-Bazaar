-- ============================================================
-- Malakand Motors — run this once in your Supabase SQL Editor.
-- The listing form no longer collects "year", so this removes
-- the requirement that every row have one. Existing rows and
-- the "chassis" column (already optional) are untouched.
-- ============================================================

alter table listings alter column year drop not null;
