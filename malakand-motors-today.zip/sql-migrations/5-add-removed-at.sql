-- ============================================================
-- Malakand Motors — run this once in your Supabase SQL Editor.
-- Adds a "removed_at" timestamp so admin.html can keep a proper
-- log of when each vehicle was listed and (if applicable) removed,
-- instead of permanently erasing the record on delete.
-- ============================================================

alter table listings add column if not exists removed_at timestamptz;
