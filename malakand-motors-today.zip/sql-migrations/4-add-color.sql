-- ============================================================
-- Malakand Motors — run this once in your Supabase SQL Editor
-- to add the "color" field to the listings table.
-- ============================================================

alter table listings add column if not exists color text;
