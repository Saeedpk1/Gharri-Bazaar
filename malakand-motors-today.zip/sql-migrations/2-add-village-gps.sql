-- ============================================================
-- Malakand Motors — run this in your Supabase project's SQL
-- Editor to add village + optional GPS fields to an existing
-- listings table. Safe to run even if columns already exist.
-- ============================================================

alter table listings add column if not exists village text;
alter table listings add column if not exists latitude double precision;
alter table listings add column if not exists longitude double precision;
