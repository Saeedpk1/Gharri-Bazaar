-- ============================================================
-- Gaari Bazaar — run this once in your NEW Supabase project's
-- SQL Editor (Supabase dashboard → SQL Editor → New query)
-- ============================================================

create extension if not exists pgcrypto;

create table if not exists listings (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  status text not null default 'pending',   -- pending | approved | rejected
  seller_name text not null,
  seller_mobile text not null,
  make text not null,
  model text not null,
  year int not null,
  mileage int not null,
  price numeric not null,
  transmission text,
  area text,
  chassis text,
  reg_status text,
  description text,
  photo_urls text[] default '{}'
);

alter table listings enable row level security;

-- Every new submission is forced to "pending", no matter what
-- the browser sends. This is what stops a seller from listing
-- their own car as already "approved".
create or replace function force_pending_status()
returns trigger as $$
begin
  new.status := 'pending';
  return new;
end;
$$ language plpgsql;

drop trigger if exists listings_force_pending on listings;
create trigger listings_force_pending
before insert on listings
for each row execute function force_pending_status();

-- Anyone can submit a new listing (this is the public "sell" form)
drop policy if exists "Public can insert listings" on listings;
create policy "Public can insert listings"
on listings for insert
to anon, authenticated
with check (true);

-- Anonymous visitors only ever see approved listings
drop policy if exists "Public can view approved listings" on listings;
create policy "Public can view approved listings"
on listings for select
to anon
using (status = 'approved');

-- You, logged in as admin, can see everything (pending/approved/rejected)
drop policy if exists "Admin can view all listings" on listings;
create policy "Admin can view all listings"
on listings for select
to authenticated
using (true);

-- You can edit and change status of any listing
drop policy if exists "Admin can update listings" on listings;
create policy "Admin can update listings"
on listings for update
to authenticated
using (true) with check (true);

-- You can delete listings
drop policy if exists "Admin can delete listings" on listings;
create policy "Admin can delete listings"
on listings for delete
to authenticated
using (true);

-- ============================================================
-- Storage bucket for car photos
-- ============================================================
insert into storage.buckets (id, name, public)
values ('car-photos', 'car-photos', true)
on conflict (id) do nothing;

drop policy if exists "Public can upload car photos" on storage.objects;
create policy "Public can upload car photos"
on storage.objects for insert
to anon, authenticated
with check (bucket_id = 'car-photos');

drop policy if exists "Public can view car photos" on storage.objects;
create policy "Public can view car photos"
on storage.objects for select
to anon, authenticated
using (bucket_id = 'car-photos');
